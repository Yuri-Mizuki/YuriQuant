# mf_fundind_check —— 批次 14：mf 干净单臂补测（2026-10-26）

> GOOD_MACHINE_TASKS 批次 14（10-26 立、当日出数终结）：批次 12② 的
> +1.44pp 混了 `ortho→ortho_fundind` 变量，本臂补**唯一变量对照**——
> `--preproc ortho_fundind --market-features --out-tag ortho920fundind_mf`
> vs 同数据态 fundind 基线。**判：❌ 不达验收（全窗 +0.49pp < +1pp 且
> Sharpe −0.010），不切 `v1-mf`，市场状态特征线收口。**

## 终数

| 项 | 数值 |
|---|---|
| mf fundind defv buffer | **16.80% / Sharpe 0.728 / 换手 21.4%**（`buffer_arm.csv`） |
| 锚（fundind 无 mf，同数据态复测） | 16.305% / 0.7377 / 20.6%（`_anchor_refund/`，与 10-21 逐位一致） |
| 全窗 Δ | **+0.49pp / ΔSharpe −0.010**（门槛 ≥+1pp ❌） |

分窗（`window_check.csv`）：Δ年化 2019+ +0.59 / 2021+ +0.31 / 2023+ +0.89 /
2025+ +2.05（5/5 为正）；ΔSharpe 仅 2025+ 为正（+0.061），其余 −0.01~−0.03。

## 判读

1. **+1.44pp 归因拆解**：去掉 fundind（标准 ortho 面板）≈ +0.8pp（与
   E5 历史 +0.81pp 吻合）+ 干净 mf 增量 ≈ +0.5pp——批次 12② 的"唯一正
   结果"降级为"混杂假象 + 真实但不足门槛的薄增量"。
2. 增量集中在近年（2025+ +2.05pp）但 Sharpe 平到微负——按预登记门槛
   （全窗 ≥+1pp 且 ≥4/5 窗年化为正）判负；与 v1w2"5/5→3/5 近窗不稳"
   先例同向保守。
3. 生产不动（dingban 维持）；`alla_daily_rank --market-features` 接线
   保留默认关；指数日线日更依赖不再需要（不采纳）。
4. 边界：`panels_neu_fundind` 缺 7 张 P5 面板，本臂沿用排除清单
   （与基线候选空间一致，见批次 12③ README 同款注记）。

## 文件清单

- `buffer_arm.csv` / `window_check.csv` —— 终数与分窗。
- `_anchor_refund/buffer_arm.csv` —— 同数据态锚点复测（逐位复现自检）。
- 重训产物主体在 `reports/alla_rolling_ortho920fundind_mf/`
  （pred / selection / metrics / `defv_sig__h1.parquet`）。
- 执行日志 `logs/batch14_*.log`。
