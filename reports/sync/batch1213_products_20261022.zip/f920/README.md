# frontier_audit_920_reval —— 批次 13：A1/A2 增量方向 920 定版复验（2026-10-21）

> GOOD_MACHINE_TASKS 批次 13（10-19 立，三臂冻结迁移：overlay w=0.40、
> stack α=0.5、h60 清单协议原样带过去，920 只验证不重调）。
> **执行环境**：本工作机 YURIMIZUKI（16C/31GB），数据面 `D:/data`
> （panels_neu 951 / panels_neu_fundind 931，income 补齐后数据态，
> 72 因子慢信号）。**总判：三臂全部不达预登记验收，A1/A2 线关闭**
> ——882 口径正结果（h60 Sharpe 1.028 / stack +0.154 / overlay +0.02）
> **均未迁移到 920 数据态**。

## 〇、主信号基座（defv 面板构造 + 登记）

- `defv_sig__h1.parquet`（2119 日 × 5816 列）：逐口径复刻
  `buffer_arm_920 --variant defv`（h1020 秩平均 ⊕ 0.5·rank(slow)，
  slow = trailing 24m ICIR / embargo 2 / min_cov 0.5 / min_months 12，
  72 因子当前数据态）。
- production 口径锚（buffer 15/40 月频 / T+1 open / 10bp / 1e6）：
  **16.31% / Sharpe 0.738 / 换手 20.6%**（与 buffer_arm_920 defv 逐位一致，
  构造自检通过）。
- `caliber.SIGNALS["dingban_fundind"]` 已从 path=None 更新为指向本面板
  （reproducible=True）；登记数 18.07/0.805 属 income 补齐前数据态，
  不可与 16.31 并列（见 baselines.yaml data_state）。

## 一、① A2 负向 overlay（walk-forward 版）—— ❌ 不采纳

命令：`residual_overlay_probe --signal dingban_fundind --weights 0.40
--walkforward --wf-csv residual_ic_h1_nonpv_s3.csv`（产物 `overlay/`）。

| 臂 | 年化 | Sharpe | ΔSharpe | 换手 |
|---|---|---|---|---|
| base（defv） | 16.31% | 0.738 | — | 20.6% |
| neg6_w040（固定集上限参照） | 18.29% | 0.823 | +0.085 | 20.0% |
| placebo_w040 | 15.69% | 0.702 | −0.036 | 20.5% |
| **wf6_w040（裁决臂）** | **15.75%** | **0.707** | **−0.030** | 23.7% |
| wf9_w040 | 15.86% | 0.712 | −0.026 | 23.6% |

验收（wf6 ΔSharpe ≥ +0.015 且近年逐年为正、placebo ≤0）：**ΔSharpe 为负，
果断否**。882 的「真实但薄 +0.02」未迁移；固定集 +0.085 与 882 同构 =
选择前视上限（非可采超额）。机制本身真实（placebo 为负）但 920 残差榜
的因子构成已变（见三），负向剔除无增量。**薄剔除规则不进进出榜链。**

## 二、② A2 二阶 GBDT 融合 —— ❌ 不采纳

命令：`residual_stack_probe --pred-dir reports/alla_rolling_ortho920fundind
--main-signal ../frontier_audit_920_reval/defv_sig__h1.parquet --audit-dir .
--alphas 0.25,0.50`（产物 `residual_stack/`；特征池 117 = 量价 35 + 非量价 82，
按 920 榜早年列重算，无选择前视口径不变）。

- stage2 OOS IC（残差收益）**0.0742 / IR 0.97**（IC(原始收益) 0.0910）——
  **IC 门槛 ≥0.02 大幅通过**，比 882 的 0.0359 翻倍；
- 组合层（2024+，main = defv 20.75%/0.821）：

| 臂 | 年化 | Sharpe | 换手 |
|---|---|---|---|
| main | 20.75% | 0.821 | 18.0% |
| fuse α=0.25 | 21.05% | 0.812 | 24.0% |
| fuse α=0.50（裁决档） | 20.91% | **0.780** | 33.8% |
| placebo α=0.50 | 18.89% | 0.719 | 32.6% |

验收（fuse α=0.50 ΔSharpe ≥ +0.08 且 placebo ≤0）：**ΔSharpe = −0.041，
果断否**（882 为 +0.154）。解释：920 定版基座更强（0.821 vs 882 主信号
0.796），且快信号 h1020 四 horizon 集成 + 慢信号已吸收 stage2 能抓到的
残差结构——**残差 IC 强 ≠ 组合层有增量**（four_paths 机理复现：
自身 IR 不足的正交信号在强基座上换不来 Sharpe）。**不进融合层候选。**

## 三、残差首轮（两份 CSV，stack/overlay 的公共输入）

- `residual_ic_h1_top200.csv`（200 个，按 registry |IC| 排序）+
  `residual_ic_h1_nonpv_s3.csv`（8 非量价族 stride=3，127 个，
  跳过 29 个覆盖不足）；主信号 = defv，h=1 可交易口径。
- **与 882 态的关键分歧**：920 榜 top5 by both_nw_t 全是**正向质量/利润率**
  （ebit_margin +5.13 / admin_exp_ratio_ttm +4.71 / ebitda_margin_ttm +4.61 /
  roic_ttm +3.52 / peg +2.79）；882 态主故事是**负向 risk/quality 剔除**。
  因子构成换了个符号方向——overlay（负向剔除）在 920 无增量与此一致。

## 四、③ A1 h60 第二策略 —— ❌ 不立项

**边界申明**：882 产物 `frontier_audit_2026-10-19/selection_h60/y2023__h60.json`
不在本机（reports 不进 git），按「选特征只依赖 h60 fwd IC、不依赖 pred 口径」
用 920 面板现算等价清单（`select_horizon_features --horizon 60 --year 2023
--panels-dir panels_neu_fundind`，产物 `selection_h60/`）。**清单构成漂移**：
50 席中 fundamental 仅 3 席（882 态 6 席；alpha191:23 / alpha158:20 主导）。

- 训练：`retrain_freq_ic --horizon 60 --sel-year 2023 --refits 60 --save-pred
  --oos 20240102~20260901` → OOS IC **0.1338 / IR 0.93 / win 78.9% / t=22.8**
  （产物 `h60_920/`）。
- 交叉 + 组合层（`cross_eval/`，2024+ production 口径）：

| 项 | 数值 | 验收线 | 判 |
|---|---|---|---|
| 同目标配对差 h20 | +0.0015（t=0.33） | \|t\|≥2（882: 3.05） | ❌ |
| 同目标配对差 h60 | +0.0026（t=0.78） | \|t\|≥2（882: 7.82） | ❌ |
| m_h60 组合 Sharpe | 0.695（ann 21.20%/换手 17.4%） | ≥ 基线 0.821−0.05=0.771 | ❌ |
| 换手 ≤ 60% 基线 | 17.4% vs 基线 18.0%（97%） | ≤10.8% | ❌ |

对照：同窗 defv 20.75%/0.821/18.0%，m_h20 23.19%/0.799/25.7%。
**「低换手第二策略」不立项**——h60 清单贡献在 920 数据态消失（IC 0.134
vs 882 态 0.180，且组合层被基座反超）。候选归因（未分离）：清单 fundamental
席位 6→3 的构成漂移；income 补齐改变质量族权重；基座本身更强。

## 五、判读与去向

1. **A1/A2 线关闭**：882 口径的三个正结果在 920 数据态全军覆没
   （−0.03 / −0.04 / 三条件全败），且方向一致 = 数据态迁移风险的真实
   标本。TODO §六 A1/A2 状态改「920 复验未过，封线归档」。
2. **机理印证**：stack 的「残差 IC 0.074 但融合层为负」是 four_paths
   2026-10-10 结论（正交信号自身 IR 不足 ⇒ 组合层换不来 Sharpe）的
   又一独立证据——920 基座越强，廉价正交增量越无处安放。
3. **正向质量因子的去向**：920 残差榜 ebit_margin/roic_ttm 等正向
   both_nw_t≥3 且逐年稳定的因子**留观**（fundamental 家族池已有席位，
   不单独开线；若未来做「质量倾斜」主题再从此榜出发）。
4. 本目录 `defv_sig__h1.parquet` 是 920 定版信号的**本机可复现实体**，
   后续任何「定版信号层」实验（overlay/注入/组合优化）都以它为基座、
   与 §〇 锚数字对照。

## 文件清单

- `defv_sig__h1.parquet` —— 定版信号面板（caliber 登记 dingban_fundind）。
- `residual_ic_h1_top200.csv` / `residual_ic_h1_nonpv_s3.csv` /
  `top_residual_h1_top200.csv` / `meta_h1_*.json` —— 残差首轮。
- `overlay/`（summary.csv / wf_factor_sets.json / meta.json）。
- `residual_stack/`（stage2_pred.parquet / stage2_ic.csv / portfolio.csv）。
- `selection_h60/`（y2023__h60.json + 质量/DPP 中间件）。
- `h60_920/`（summary.csv / pred_refit060.parquet / ic_refit060.csv）。
- `cross_eval/`（ic 配对差 + portfolio.csv）。
- 执行日志：`logs/batch12/13*.log`（仓库外工作日志，不随产物分发）。
