# ortho920fundind_lblco —— 批次 12③：隔夜标签臂（2026-10-22）

> GOOD_MACHINE_TASKS 批次 12③：训练标签改 close→next open 隔夜收益
> （`--label-window co --horizons 1`，Label Alchemy Scenario 1 证据；评价
> 口径仍 cc 原始收益），单臂对照 fundind 基线（`alla_rolling_ortho920fundind`
> 同配置 cc 标签）。**判：❌ 判负归档——全主口径行 −0.5~−1.3pp 且换手升高。**

## 终表（`metrics_overall.csv`，open，月频）

| run_id | lblco 年化/Sharpe/换手 | fundind 基线 | Δ年化 |
|---|---|---|---|
| gbdt__h1__M__raw__f0.20 | 10.55% / 0.438 / 73.0% | 11.06% / 0.473 | −0.52pp |
| gbdt__h1__M__raw__f0.10 | 9.88% / 0.400 / 83.4% | 11.22% / 0.478 | **−1.34pp** |
| gbdt__h1__M__neut__f0.20 | 5.86% / 0.232 / 76.8% | 7.05% / 0.283 | −1.19pp |

gbdt 主模型三行一致为负，换手全面升高（+4~10pp）；ridge 族在隔夜标签下
大面积崩溃（部分行年化 −40%+，见 `logs/batch12/12c_lblco5.log`——隔夜段
噪声占比远高于日频 cc，线性模型首当其冲）。

## 判读

1. **「标签与执行价同口径」直觉不成立**：隔夜段收益的可预测成分低于
   close-close 全日段（A股隔夜跳空噪声主导），训练标签换到隔夜段是
   **丢信息**而非对齐。与 882 时代 ortho920tl 基座 lblco 判负（§〇 负结果
   清单「标签工程三臂 co、ir 判负」）双基座互证——**标签工程线彻底收口**。
2. 环境注记：本机 panels_neu_fundind 缺 7 张 P5 面板（P5 只补进了
   panels_neu）——已通过 `--exclude-features` 排除（基线 fundind 当年候选
   空间同样无此 7 者，配对比较不受影响）；select 全网格照跑（管线设计，
   ic 缓存与 --horizons 无关），predict 仅 h1。

## 工程副产物（随本批入库）

- `rolling_grid_alla.py` 修复：`--exclude-features` 此前被基本面/另类族
  `_extra` 补位池绕过（_extra 从 registry 取名而非 quality 榜）——本次
  实测踩坑后修复，`tests/test_rolling_grid_alla.py` 19 用例全绿（含
  exclude 全路径覆盖锚）。

## 文件清单

- 管线产物：`pred/`（h1 各模型）、`selection/`、`equity/`、
  `metrics_overall.csv`、`metrics_yearly.csv`、`ic_stats.csv`。
- 执行日志 `logs/batch12/12c_lblco*.log`（1/3 为失败踩坑留痕，
  5 为终跑）。
