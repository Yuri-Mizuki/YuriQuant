# ortho920mf —— 批次 12②：市场状态特征全A 重训（2026-10-21/22）

> GOOD_MACHINE_TASKS 批次 12②：`--market-features`（国金19 转译；上证指数
> + 国证A指点位派生日级广播特征，旁路并入 GBDT 特征集、不过 select 漏斗）。
> 命令 = ortho920tl 同配置 + `--market-features --out-tag ortho920mf`。
> **判：✅ 本批次唯一正结果——定版形态 +1.44pp / Sharpe +0.032，
> 5/5 窗年化为正，达「>±1pp 才值得并入」线；生产切换建议挂由莉酱拍板。**

## 数据/环境

- 国证A指（399317_SZ）本地缓存缺失，10-21 已经 AmazingData SDK 补拉
  （`D:/data/parquet/index_daily_399317_SZ.parquet`，2865 行）——两指数广播
  特征全期可用（上证 000001_SH 原有）。
- 执行环境 = 本工作机当前数据态（income 补齐后），与 defv 锚 16.31/0.738
  **同态配对**（batch 1 时代 tl/fundind 基线跑在补齐前旧态，本表不与之并列）。

## 结果

**单模型主口径（`metrics_overall.csv`，open，h1 M raw f0.20）**：
mf 11.02%/0.453 vs fundind 11.06%/0.473——单模型层无差（Δ −0.04pp）。

**定版形态配对对照（`buffer_defv/buffer_arm.csv`，唯一变量 = 市场特征旁路）**：

| 形态 | 年化 | Sharpe | 换手 |
|---|---|---|---|
| naive_top20 | 17.20% | 0.725 | 49.8% |
| **buffer_15_40（mf）** | **17.74%** | **0.769** | **21.0%** |
| （锚：无 mf defv buffer） | 16.31% | 0.738 | 20.6% |

**分窗稳健性（`window_check.csv`）**：

| 窗 | Δ年化 pp | ΔSharpe |
|---|---|---|
| 全窗2018+ | **+1.44** | +0.032 |
| 2019+ | +1.72 | +0.037 |
| 2021+ | +1.05 | +0.007 |
| 2023+ | +0.72 | −0.026 |
| 2025+ | +2.32 | +0.066 |

## 判读

1. **5/5 窗年化为正（+0.7~+2.3pp）、4/5 Sharpe 为正、换手不变（21.0 vs
   20.6%）**——市场状态特征在**定版信号层**构成真实增量；单模型 h1 层无差
   ⇒ 增量来自长 horizon 分量（指数均线/52 周位置类广播特征与 h10/h20
   天然同频，快信号 h1 吃不到）。
2. 边界：h1 单模型 −0.04pp 说明该特征**不是万能撒料**；2023+ 窗 Sharpe
   微负（+0.72pp 年化仍正）——近年贡献略缩。总体仍稳过 ±1pp 线。
3. **建议动作**（待拍板，不擅自切）：生产出榜链 `rolling_grid_alla` 侧
   无需动（生产链用的是既有 pred）；采纳 = 后续全量重训默认带
   `--market-features`，或按 dingban 切换纪律走三处联动登记。
4. `defv_sig__h1.parquet` = mf 版定版信号面板（后续任何对照用它）。

## 文件清单

- 管线产物：`pred/`（5 模型 × 4 horizon）、`selection/`、`equity/`、
  `metrics_overall.csv`、`metrics_yearly.csv`、`ic_stats.csv`。
- `buffer_defv/buffer_arm.csv` —— 定版形态对照。
- `window_check.csv` + `defv_sig__h1.parquet` —— 分窗稳健性与信号面板。
- 执行日志 `logs/batch12/12b_mf.log`、`logs/batch12/12b_buffer_defv.log`。
